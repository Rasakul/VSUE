package test.util;

public enum Flag {
	REGEX, LAST, NOT
}
