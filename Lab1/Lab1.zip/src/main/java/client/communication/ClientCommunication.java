package client.communication;

import java.io.Closeable;

/**
 * Created by Lukas on 16.10.2015.
 */
public interface ClientCommunication extends Runnable, Closeable {}
